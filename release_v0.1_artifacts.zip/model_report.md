# Model report
- Mean CV accuracy: 0.829 ± 0.013
- Hold-out accuracy: 0.793
